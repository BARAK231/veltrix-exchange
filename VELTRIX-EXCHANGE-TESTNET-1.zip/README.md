# VELTRIX EXCHANGE — TESTNET

A simple simulated VLX/USDT exchange interface for testing.

## Run
```bash
npm install
npm start
```

The app uses port 10000 by default (or `PORT` from the environment).

## Important
This version is DEMO/TESTNET only. It does not handle real money, private keys, blockchain withdrawals, or real customer funds.
